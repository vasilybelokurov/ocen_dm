# Omega Centauri: first dynamical experiments

LaTeX source, ten PNG figures and numerical provenance for the pilot report,
including the analytical comparisons in Section 6.

Compile from docs/ with a standard TeX Live installation:

    cd docs
    latexmk -pdf dynamical_batch.tex

All figures are PNGs in plots/. Numerical data and JSON provenance live in
results/plot_data/. The compiled document PDF belongs beside the
LaTeX source in docs/. No external bibliography or simulation data is needed
to compile. Regenerating the scientific figures requires the project code
and preserved simulations; the analytical comparison uses
bin/compare_dynamical_analytics.py. Unrounded comparison values, definitions,
quadrature checks, input hashes and code hashes are in
results/plot_data/dynamical_analytics.json. Temporal ranges are not confidence intervals.
